/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sellinmuliokhumairoh;

/**
 *
 * @author anggu
 */
public class Sellinmuliokhumairoh {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
